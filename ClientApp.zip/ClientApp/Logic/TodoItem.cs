namespace ClientApp.Logic;

public class TodoItem
{
    public bool IsDone { get; set; }
    public string Title { get; set; } = "";
}