namespace ClientApp.Model;

public class User
{
    public string Name { get; set; } = String.Empty;
    public string Role { get; set; } = "none";
    public string Password { get; set; } = String.Empty;
}